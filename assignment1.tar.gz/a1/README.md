# Assignment 1

This is the folder for CMPUT 379 - Assignment 1, Created by Stephen Larsen & Hayden Bauder

All driver files are in the /tests sub-directory along with its own Makefile and README, named TESTS.txt.

The top-level Makefile calls commands in the sub-level Makefile and has more specific documentation within the comments. It is recommended to run ```make clean``` before testing with a new pattern.


## License
```
Copyright (C) 2017 Stephen Larsen & Hayden Bauder
Licensed under the GNU Public License, Version 3.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

      https://www.gnu.org/licenses/gpl-3.0.txt

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
```
